//
//  ViewController.swift
//  animation_ui
//
//  Created by Aman Afzalbeg Mirza on 04/03/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var animatedView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func movebtn(_ sender: Any) {
        UIView.animate(withDuration: 0.5) {
            self.animatedView.transform = self.animatedView.transform.translatedBy(x: 50, y: 0)
    }
    }
    
    
    @IBAction func scale(_ sender: Any) {
        UIView.animate(withDuration: 1.0) {
            self.animatedView.transform = self.animatedView.transform.scaledBy(x: 1.5, y: 1.5)
        }
    }
    
    @IBAction func rotate(_ sender: Any) {
        UIView.animate(withDuration: 0.5) {
            self.animatedView.transform = self.animatedView.transform.rotated(by: .pi)
        }
    }
    
    @IBAction func fade(_ sender: Any) {
        UIView.animate(withDuration: 1.0) {
            self.animatedView.alpha = 0.2
        }
    }
    
    @IBAction func reset(_ sender: Any) {
        UIView.animate(withDuration: 0.5) {
            self.animatedView.transform = .identity
            self.animatedView.alpha = 1
        }
    }
    
}

