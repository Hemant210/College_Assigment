//
//  ViewController.swift
//  drag drop
//
//  Created by Aman Afzalbeg Mirza on 03/03/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let gesture = UIPinchGestureRecognizer(target: self, action: #selector(pinch(sender:)))
        view.addGestureRecognizer(gesture)
        
        let gesture2 = UIRotationGestureRecognizer(target: self, action: #selector(rotate(sender:)))
        view.addGestureRecognizer(gesture2)
        
    }
    
    @objc func pinch(sender:UIPinchGestureRecognizer){
        sender.view?.transform = sender.view!.transform.scaledBy(x: sender.scale, y: sender.scale)
        sender.scale = 1.0
    }
    
    @objc func rotate(sender:UIRotationGestureRecognizer){
        sender.view?.transform = sender.view!.transform.rotated(by: sender.rotation)
        sender.rotation = 0.0
    }
}

extension ViewController: UIGestureRecognizerDelegate {
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                           shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true   
    }
}

