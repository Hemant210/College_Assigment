//
//  ViewController.swift
//  swipe_gestures
//
//  Created by Aman Afzalbeg Mirza on 03/03/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var swipeLable: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let swipeUP = UISwipeGestureRecognizer(target: self, action: #selector(swipeUp))
        swipeUP.direction = .up
        self.view.addGestureRecognizer(swipeUP)
        
        let swipeDOWN = UISwipeGestureRecognizer(target: self, action: #selector(swipeDown))
        swipeDOWN.direction = .down
        self.view.addGestureRecognizer(swipeDOWN)
        
        let swipeLEFT = UISwipeGestureRecognizer(target: self, action: #selector(swipeLeft))
        swipeLEFT.direction = .left
        self.view.addGestureRecognizer(swipeLEFT)
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeRight))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)
    }
    
    @objc func swipeUp() {
        swipeLable.text = "Swiped Up"
        view.backgroundColor = .red
    }
    
    @objc func swipeDown() {
        swipeLable.text = "Swiped Down"
        view.backgroundColor = .blue
    }
    
    @objc func swipeLeft() {
        swipeLable.text = "Swiped Left"
        view.backgroundColor = .green
    }
    
    @objc func swipeRight() {
        swipeLable.text = "Swiped Right"
        view.backgroundColor = .orange
    }
}

