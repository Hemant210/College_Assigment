//
//  StudentCell.swift
//  TableView
//
//  Created by Aman Afzalbeg Mirza on 28/02/26.
//

import UIKit

class StudentCell: UITableViewCell {

    
    @IBOutlet weak var rollLabel: UILabel!
    @IBOutlet weak var nameLable: UILabel!
    @IBOutlet weak var marksLable: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
