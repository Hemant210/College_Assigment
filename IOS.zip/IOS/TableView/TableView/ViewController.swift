import UIKit

struct Student {
    var rollNumber: Int
    var name: String
    var marks: Double
}

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var rollTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var marksTextField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    var students: [Student] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    // MARK: - Add Student Button
    
    @IBAction func addStudentButton(_ sender: Any) {
        
        guard let rollText = rollTextField.text,
              let roll = Int(rollText),
              let name = nameTextField.text, !name.isEmpty,
              let marksText = marksTextField.text,
              let marks = Double(marksText) else {
            
            showAlert(title: "Error", message: "Please enter valid data")
            return
        }
        
        let newStudent = Student(rollNumber: roll, name: name, marks: marks)
        students.append(newStudent)
        
        tableView.reloadData()
        
        rollTextField.text = ""
        nameTextField.text = ""
        marksTextField.text = ""
        
        showAlert(title: "Success", message: "Student Added Successfully")
    }
    
    // MARK: - TableView Methods
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return students.count
    }
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "StudentCell",
                                                 for: indexPath) as! StudentCell
        
        let student = students[indexPath.row]
        
        cell.rollLabel.text = "\(student.rollNumber)"
        cell.nameLable.text = student.name
        cell.marksLable.text = String(format: "%.2f", student.marks)
        
        return cell
    }
    
    // MARK: - Header View (Column Titles)
    
    func tableView(_ tableView: UITableView,
                   viewForHeaderInSection section: Int) -> UIView? {
        
        let headerView = UIView()
        headerView.backgroundColor = UIColor.systemGray5
        
        let rollLabel = UILabel()
        rollLabel.text = "Roll No"
        rollLabel.textAlignment = .center
        rollLabel.font = UIFont.boldSystemFont(ofSize: 16)
        
        let nameLabel = UILabel()
        nameLabel.text = "Name"
        nameLabel.textAlignment = .center
        nameLabel.font = UIFont.boldSystemFont(ofSize: 16)
        
        let marksLabel = UILabel()
        marksLabel.text = "Marks"
        marksLabel.textAlignment = .center
        marksLabel.font = UIFont.boldSystemFont(ofSize: 16)
        
        let stack = UIStackView(arrangedSubviews: [rollLabel, nameLabel, marksLabel])
        stack.axis = .horizontal
        stack.distribution = .fillEqually
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        headerView.addSubview(stack)
        
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: headerView.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: headerView.trailingAnchor),
            stack.topAnchor.constraint(equalTo: headerView.topAnchor),
            stack.bottomAnchor.constraint(equalTo: headerView.bottomAnchor)
        ])
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView,
                   heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    // MARK: - Alert
    
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title,
                                      message: message,
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
